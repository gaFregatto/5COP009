SELECT cod_depto, num_disc 
FROM disciplina 
WHERE LOWER(nome_disc) LIKE '%acao%';