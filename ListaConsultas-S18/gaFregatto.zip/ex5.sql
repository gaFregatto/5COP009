SELECT data_embarq 
FROM embarque
WHERE cod_fornec = 'F1';