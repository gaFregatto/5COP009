SELECT CONCAT(LOWER(nome_disc), '(', LOWER(cod_depto), ')') 
AS cod_disc_depto 
FROM disciplina;