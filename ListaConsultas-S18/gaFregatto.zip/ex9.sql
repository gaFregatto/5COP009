SELECT cod_prof, nome_prof
FROM professor
WHERE cod_tit IS NULL;