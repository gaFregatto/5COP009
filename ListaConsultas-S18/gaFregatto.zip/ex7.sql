SELECT DISTINCT nome_disc
FROM disciplina
WHERE creditos_disc > 4;