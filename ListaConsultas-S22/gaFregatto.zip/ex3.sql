DELETE FROM prof_oferta
    WHERE cod_depto = 'MAT01';

DELETE FROM periodo 
    WHERE cod_depto = 'MAT01';

DELETE FROM oferta
    WHERE cod_depto = 'MAT01';