SELECT MAX(peso_peca) AS maior_peso
FROM peca;