SELECT COUNT(DISTINCT cod_fornec)
AS fornecedores_c_embarque
FROM embarque